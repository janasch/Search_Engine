package ScoringTests;

import Index.*;
import Main.*;
import Scoring.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import java.util.ArrayList;
import java.util.Arrays;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class BM25ExtScoreTest extends ScoringTest {

    @BeforeEach
    void setUp() {
        sites = new ArrayList<>();
        sites.add(new Website("w1.com", "word1", Arrays.asList("word1", "word2", "word2", "word3")));
        sites.add(new Website("w2.com", "word1", Arrays.asList("word1", "word2", "word2")));
        sites.add(new Website("w3.com", "word1 word2", Arrays.asList("word1", "word2", "word2")));
        sites.add(new Website("w4.com", "word1", Arrays.asList("word2", "word3", "word3")));
        sites.add(new Website("w5.com", "title1", Arrays.asList("word6")));
        sites.add(new Website("w6.com", "title1", Arrays.asList("word6")));
        sites.add(new Website("w7.com", "title1", Arrays.asList("word6")));
        sites.add(new Website("w8.com", "title1", Arrays.asList("word6")));
        sites.add(new Website("w9.com", "word2", Arrays.asList("word6", "word2")));

        indx = new InvertedIndexHashMap();
        indx.build(sites);

    }


    @AfterEach
    void tearDown() {
        indx = null;
    }


    @Test
    public void test01() {
        String word = "word1";
        // compare BM25 against BM25 website1
        //website1
        double scoreBM25 = new BM25Score().getScore(word, sites.get(0), indx);
        double scoreBM25ext = new BM25ExtScore().getScore(word, sites.get(0), indx);
        double idf = new IDFScore().getScore(word, sites.get(0), indx);
        assertTrue (idf > 1);
        assertTrue(scoreBM25 < scoreBM25ext);
    }

    @Test
    public void test02() {
        String word = "word1";
        // compare website1 and website2 (same occ. in title and body, w1 has more words in body)
        //website1
        double scoreBM25extW1 = new BM25ExtScore().getScore(word, sites.get(0), indx);
        //score for website2
        double scoreBM25extW2 = new BM25ExtScore().getScore(word, sites.get(1), indx);
        assertTrue(scoreBM25extW1<scoreBM25extW2);
    }

    @Test
    public void test03() {
        String word = "word1";
        // compare website2 and website3, w3 has more words in title
        //score for website3
        double scoreBM25extW3 = new BM25ExtScore().getScore(word, sites.get(2), indx);
        //score for website2
        double scoreBM25extW2 = new BM25ExtScore().getScore(word, sites.get(1), indx);
        assertTrue(scoreBM25extW3 < scoreBM25extW2);
    }

    @Test
    public void test04() {
        String word = "word1";
        // compare website4 and website2, w4 has word in title, but not in body
        //website3
        double scoreBM25extW4 = new BM25ExtScore().getScore(word, sites.get(3), indx);
        //score for website2
        double scoreBM25extW2 = new BM25ExtScore().getScore(word, sites.get(1), indx);
        assertTrue(scoreBM25extW4 < scoreBM25extW2);
    }

    @Test
    public void test05() {
        String word = "word2";
        // the IDF should be below the threshold, BM25ext should equal BM25
        double scoreBM25 = new BM25Score().getScore(word, sites.get(8), indx);
        double scoreBM25ext = new BM25ExtScore().getScore(word, sites.get(8), indx);
        assertEquals(scoreBM25, scoreBM25ext);
    }

    @Test
    public void test06() {
        //testing that the bonus is calculated correctly when title contains 1 word
        String word = "word1";
        double scoreBM25 = new BM25Score().getScore(word, sites.get(0), indx);
        double scoreBM25ext = new BM25ExtScore().getScore(word, sites.get(0), indx);
        assertEquals(scoreBM25*(1+1), scoreBM25ext);
    }

    @Test
    public void test07() {
        //testing that the bonus is correct when title contains more than 1 word
        String word = "word1";
        double scoreBM25 = new BM25Score().getScore(word, sites.get(2), indx);
        double scoreBM25ext = new BM25ExtScore().getScore(word, sites.get(2), indx);
        assertEquals(scoreBM25*(1+0.5), scoreBM25ext);
    }

}

