package ScoringTests;

public class test {
    public static void main(String[] args) {

        String w = "";

        if (w.isEmpty()){
            System.out.println(1);
        }
    }
}
