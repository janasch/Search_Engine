package MainTests;

import Main.*;
import Index.*;
import Scoring.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class QueryHelperTest {

    /**
     * @ author Leah Peschel
     * A class for unit testing
     */

    Index indx;
    QueryHelper queryHelp;
    Score score;
    List<Website> sites;
    RankHelper rank;

    @BeforeEach
    void setup() {

        indx = new InvertedIndexHashMap();
        score = new TFIDFScore();
        queryHelp = new QueryHelper(indx);
        sites = new ArrayList<>();
        rank = new RankHelper(indx);

        sites.add(new Website("w1.com", "D-words", Arrays.asList("Donkey", "Donald", "Dnmrk")));
        sites.add(new Website("w2.com", "Denmark and Uruguay", Arrays.asList("Africa", "Uruguay", "Denmark")));

        // same website added twice
        sites.add(new Website("w3.com", "Denmark", Arrays.asList("Copenhagen", "Denmark")));
        sites.add(new Website("w3.com", "Denmark", Arrays.asList("Copenhagen", "Denmark")));

        sites.add(new Website("w4.com", "Brasil", Arrays.asList("Brasília", "capital", "Brasil")));
        sites.add(new Website("w5.com", "Zoo", Arrays.asList("animal", "Zoo")));

        sites.add(new Website("w6.com", "matches words of 3 websites", Arrays.asList("Copenhagen", "animal", "Brasil")));
        sites.add(new Website("w7.com", "or", Arrays.asList("or", "OR", "Or")));

        indx.build(sites);
    }


    @AfterEach
    void tearDown() {

        indx = null;
        score = null;
        queryHelp = null;
        sites.clear();
    }

    @Test
    void testSingleWord_MatchingWebsites() {
        String query = "Brasil";
        assertEquals(2, queryHelp.getMatchingWebsites(query).size());

    }

    @Test
    void testMultipleWords_MatchingWebsites() {
        String query = "Copenhagen animal";
        assertEquals(1, queryHelp.getMatchingWebsites(query).size()); // Expected: ws containing both words
        assertEquals("[Main.Website{title='matches words of 3 websites', url='w6.com', words=[Copenhagen, animal, Brasil]}]"
                , queryHelp.getMatchingWebsites(query).toString());
    }

    @Test
        // single 'OR' in query
    void testSingleORQuery_MatchingWebsites() {
        String query = "Denmark OR Brasil";
        assertEquals(4, queryHelp.getMatchingWebsites(query).size()); // Expected: ws containing one or the other word, ws may contain both words
        assertEquals("[Main.Website{title='Denmark', url='w3.com', words=[Copenhagen, Denmark]}, " +
                        "Main.Website{title='Denmark and Uruguay', url='w2.com', words=[Africa, Uruguay, Denmark]}, " +
                        "Main.Website{title='matches words of 3 websites', url='w6.com', words=[Copenhagen, animal, Brasil]}, " +
                        "Main.Website{title='Brasil', url='w4.com', words=[Brasília, capital, Brasil]}]"
                , queryHelp.getMatchingWebsites(query).toString());

    }


    @Test
        // multiple OR in multiple word query
        // two OR finding the same website
    void testMultipleORQuery_MatchingWebsites() {
        String query = "Donkey Donald OR animal Zoo OR animal";
        assertEquals(3, queryHelp.getMatchingWebsites(query).size());
        assertEquals("[Main.Website{title='Zoo', url='w5.com', words=[animal, Zoo]}, " +
                        "Main.Website{title='D-words', url='w1.com', words=[Donkey, Donald, Dnmrk]}, " +
                        "Main.Website{title='matches words of 3 websites', url='w6.com', words=[Copenhagen, animal, Brasil]}]"
                , queryHelp.getMatchingWebsites(query).toString());


    }

    // test corner cases for method matching websites

    @Test
    void testSpecialCharacters_MatchingWebsites() {
        String query = "(animal), \"Zo?o\"";
        assertEquals(1, queryHelp.getMatchingWebsites(query).size());
        assertEquals("[Main.Website{title='Zoo', url='w5.com', words=[animal, Zoo]}]", queryHelp.getMatchingWebsites(query).toString()); // add expected result

    }

    @Test
        //test spaces between query words
    void testSpaces2_MatchingWebsites() {
        String query = "   animal    Zoo";
        assertEquals(1, queryHelp.getMatchingWebsites(query).size());
        assertEquals("[Main.Website{title='Zoo', url='w5.com', words=[animal, Zoo]}]", queryHelp.getMatchingWebsites(query).toString()); // add expected result

    }

    @Test
        // single, lower case 'or'
    void testSingleorQuery_MatchingWebsites() {
        String query = "Denmark or Zoo";
        assertEquals(0, queryHelp.getMatchingWebsites(query).size());

    }


    @Test
    void testSpecialCharacters_OR_MatchingWebsites() {
        String query = "(Donkey) Donald OR \"Zoo\"";
        assertEquals(2, queryHelp.getMatchingWebsites(query).size());

    }


    @Test
        // multiple, repeated OR in query
    void testRepeatedOR_MatchingWebsites() {
        String query = "Animal OR OR OR OR Zoo";
        assertEquals(0, queryHelp.getMatchingWebsites(query).size());
    }

    @Test
        // mix of lower and upper case letters
    void testLowerUpperCase_MatchingWebsites() {
        String query = "AnIMal OR ZoO";
        assertEquals(2, queryHelp.getMatchingWebsites(query).size());
        assertEquals("[Main.Website{title='Zoo', url='w5.com', words=[animal, Zoo]}, " +
                        "Main.Website{title='matches words of 3 websites', url='w6.com', words=[Copenhagen, animal, Brasil]}]"
                , queryHelp.getMatchingWebsites(query).toString());

    }


    @Test
    void testNotIndexedWord_MatchingWebsites() {
        String query = "Hello";
        assertEquals(0, queryHelp.getMatchingWebsites(query).size());

    }


    /**
     * testing: evaluateFullQuery () of class QueryHelper
     */

    @Test
    void testSingleWordQuery_FullQuery() {
        String[] query = {"Denmark"};
        assertEquals(2, queryHelp.evaluateFullQuery(query).size());

    }

    @Test
    void testMultipleWordQueryContainingOR_FullQuery() {
        // website(s) must contain or denmark or animal
        String[] query = {"Denmark Uruguay", "Zoo"};
        assertEquals(2, queryHelp.evaluateFullQuery(query).size());
        assertEquals("{Main.Website{title='Zoo', url='w5.com', words=[animal, Zoo]}=3.3846153846153846, " +
                        "Main.Website{title='Denmark and Uruguay', url='w2.com', words=[Africa, Uruguay, Denmark]}=4.680851063829787}"
                , queryHelp.evaluateFullQuery(query).toString());
    }


    @Test
    void testMultipleWordQueryContainingMultipleOR_FullQuery() {
        String[] query = {"Denmark Copenhagen", "Zoo", "Donkey"};
        assertEquals(3, queryHelp.evaluateFullQuery(query).size());
    }

    @Test
    void testSpacesinQuery_FullQuery() {
        String[] query = {"Denmark       Copenhagen", "Zoo"};
        assertEquals(2, queryHelp.evaluateFullQuery(query).size());

    }

    @Test
    void testNotIndexedWords_FullQuery() {
        String[] query = {"Hello"};
        assertEquals(0, queryHelp.evaluateFullQuery(query).size());
    }


    /**
     * testing: evaluateSubQuery () of class QueryHelper
     */

    @Test
    void testSingleWordQuery_SubQuery() {
        String[] query = {"Denmark"};
        assertEquals(2, queryHelp.evaluateSubQuery(query).size());

    }

    @Test
    void testMultipleWordQuery_SubQuery() {
        // website(s) must contain denmark and uruguay
        String[] query = {"Denmark", "Uruguay"};
        assertEquals(1, queryHelp.evaluateSubQuery(query).size());
    }


    @Test
    void testNotIndexedWords_SubQuery() {
        String[] query = {"Hello"};
        assertEquals(0, queryHelp.evaluateSubQuery(query).size());
    }
}







