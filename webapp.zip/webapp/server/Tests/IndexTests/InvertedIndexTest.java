package IndexTests;

import Main.*;
import Index.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;


/**
 * @description A class to test the InvertedIndex implementation
 * @author Sarah Amick, Leah Peschel
 */
abstract class InvertedIndexTest {

       Index invertedIndex;

       public InvertedIndexTest(Index index){
           this.invertedIndex = index;
       }

        @BeforeEach
        void setUp(){
            List<Website> sites = new ArrayList<>();
            sites.add(new Website("A_e1.com", "A_title1", Arrays.asList("Alaska", "Aunt")));

            // add the same website twice to the list
            sites.add(new Website("B_e2.com", "B_title2", Arrays.asList("Build", "Bound")));
            sites.add(new Website("B_e2.com", "B_title2", Arrays.asList("Build", "Bound")));

            // exceptions : empty string in title, empty list of words, special characters
            sites.add(new Website("C_e3.com", "C_title3", Arrays.asList("Cosine", "Alaska")));
            sites.add(new Website("E_e4.com", "E_title4", new ArrayList<>()));
            sites.add(new Website("eäöü5.com", "titléäöü5?#", Arrays.asList("äüö!'#")));

            invertedIndex.build(sites);

        }

        @AfterEach
        void tearDown(){
            invertedIndex = null;
        }


        @Test
        void testLookup() {
            //tests whether the size of the returned list equals the right number of websites
            assertEquals(2, invertedIndex.lookup("Alaska").size());
            assertEquals(1, invertedIndex.lookup("Bound").size());

            //tests whether the lookup method works with wildcard
            assertEquals(2, invertedIndex.lookup("Ala*").size());
            assertEquals("[Main.Website{title='A_title1', url='A_e1.com', words=[Alaska, Aunt]}, " +
                                   "Main.Website{title='C_title3', url='C_e3.com', words=[Cosine, Alaska]}]",
                    invertedIndex.lookup("A*").toString());

            //tests whether the lookup method matches the right websites according to query word
            assertEquals("[Main.Website{title='titléäöü5?#', url='eäöü5.com', words=[äüö!'#]}]",
                    invertedIndex.lookup("äüö!'#").toString());

            //tests whether the lookup method works with keyword 'site:'
            assertEquals("[Main.Website{title='E_title4', url='E_e4.com', words=[]}]",
                    invertedIndex.lookup("site:e4").toString());

            //tests whether the lookup method returns an empty list for a non-existent query word
            assertEquals(0, invertedIndex.lookup("gyjk").size());
            assertEquals("[]", invertedIndex.lookup("Alaska, Cosine").toString());

        }

    }

