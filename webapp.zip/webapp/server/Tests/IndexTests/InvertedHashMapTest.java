package IndexTests;

import Index.*;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * @description A class that extends InvertedIndexTest with a HashMap implementation
 * @author Sarah Amick, Leah Peschel
 */
public class InvertedHashMapTest extends InvertedIndexTest {

    public InvertedHashMapTest(){
        super(new InvertedIndexHashMap());
    }

    @Test
    void testBuild() {

        //tests whether the index is built correctly:
        assertEquals( "class Index.InvertedIndexHashMap {" +
                        "Aunt=[Main.Website{title='A_title1', url='A_e1.com', words=[Alaska, Aunt]}], " +
                        "Build=[Main.Website{title='B_title2', url='B_e2.com', words=[Build, Bound]}], " +
                        "Bound=[Main.Website{title='B_title2', url='B_e2.com', words=[Build, Bound]}], " +
                        "Alaska=[Main.Website{title='A_title1', url='A_e1.com', words=[Alaska, Aunt]}, Main.Website{title='C_title3', url='C_e3.com', words=[Cosine, Alaska]}], " +
                        "Cosine=[Main.Website{title='C_title3', url='C_e3.com', words=[Cosine, Alaska]}], " +
                        "äüö!'#=[Main.Website{title='titléäöü5?#', url='eäöü5.com', words=[äüö!'#]}]}"
                , invertedIndex.toString());
    }
}
