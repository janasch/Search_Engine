package Scoring;
import Main.*;
import Index.*;

/**
 *  The simple Score returns always 0, thus it does not rank.
 *  * @Jana Schmurr
 */

public class SimpleScore implements Score {

        public double getScore(String word, Website site, Index index){
            double score = 0.0;
        return score;
    }
}
